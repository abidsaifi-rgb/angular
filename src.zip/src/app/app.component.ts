import { Component } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ang10';
  showHSF: boolean = true;

  constructor(private router: Router){

    router.events.forEach((event) => {
      if (event instanceof NavigationStart) {
        if (event['url'] == '/') {
          this.showHSF = true;
          //this.router.navigate(['/login']);
        } else {
          // console.log("NU")
          this.showHSF = false;
        }
      }
    });
  }

}
