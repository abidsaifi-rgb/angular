import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { ListComponent } from './list/list.component';
import { CourselistComponent } from './courselist/courselist.component';
console.warn("this is admin module");

@NgModule({
  declarations: [ListComponent, CourselistComponent],
  imports: [
    CommonModule,
    AdminRoutingModule
  ]
})
export class AdminModule { }
