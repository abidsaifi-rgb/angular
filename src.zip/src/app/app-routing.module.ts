import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';

const routes: Routes = [
  //{path:'', component :HomepageComponent},
  {path:'about', component :AboutComponent},
  {path:'contact', component :ContactComponent},

  { path: 'admin', loadChildren: () => import(`./admin/admin.module`).then(m => m.AdminModule) },
  { path: 'user', loadChildren: () => import(`./user/user.module`).then(u => u.UserModule) },
  { path: 'packages', loadChildren: () => import(`./packages/packages.module`).then(p => p.PackagesModule) },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
