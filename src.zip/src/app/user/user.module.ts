import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserRoutingModule } from './user-routing.module';
import { ListComponent } from './list/list.component';
import { CourselistComponent } from './courselist/courselist.component';
console.warn("this is user module");  

@NgModule({
  declarations: [ListComponent, CourselistComponent],
  imports: [
    CommonModule,
    UserRoutingModule
  ]
})
export class UserModule { }
