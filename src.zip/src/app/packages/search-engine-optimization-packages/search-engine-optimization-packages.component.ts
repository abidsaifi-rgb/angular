import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-engine-optimization-packages',
  templateUrl: './search-engine-optimization-packages.component.html',
  styleUrls: ['./search-engine-optimization-packages.component.css']
})
export class SearchEngineOptimizationPackagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
