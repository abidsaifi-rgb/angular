import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchEngineOptimizationPackagesComponent } from './search-engine-optimization-packages.component';

describe('SearchEngineOptimizationPackagesComponent', () => {
  let component: SearchEngineOptimizationPackagesComponent;
  let fixture: ComponentFixture<SearchEngineOptimizationPackagesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchEngineOptimizationPackagesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchEngineOptimizationPackagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
