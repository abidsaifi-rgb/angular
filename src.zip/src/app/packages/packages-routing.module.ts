import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
//import { SearchEngineOptimizationPackagesComponent } from './SearchEngineOptimizationPackagesComponent/SearchEngineOptimizationPackagesComponent.component';
import { SearchEngineOptimizationPackagesComponent } from './search-engine-optimization-packages/search-engine-optimization-packages.component';

const routes: Routes = [
  {path:'searchengineoptimizationpackagescomponent', component :SearchEngineOptimizationPackagesComponent}
  //{path:'list', component :ListComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PackagesRoutingModule { }
