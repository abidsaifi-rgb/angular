import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PackagesRoutingModule } from './packages-routing.module';
import { SearchEngineOptimizationPackagesComponent } from './search-engine-optimization-packages/search-engine-optimization-packages.component';
console.warn("this is packages modusl");

@NgModule({
  declarations: [SearchEngineOptimizationPackagesComponent],
  imports: [
    CommonModule,
    PackagesRoutingModule
  ]
})
export class PackagesModule { }
