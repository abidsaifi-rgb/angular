import { Component, OnInit } from '@angular/core';
console.warn("this is contact comoponent");

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  constructor() { 
    console.warn("this is contact comoponent constructor");
  }

  ngOnInit(): void {
  }

}
